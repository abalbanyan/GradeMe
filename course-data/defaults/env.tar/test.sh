#!/bin/bash

echo "test success"
