#!/bin/bash

echo "[1] (pass) Initialize payroll"
echo "[1] (pass) Initialize employee"
echo "[5] (pass) Add employee to payroll"
echo "[5] (fail) Find employee on payroll # Returned wrong employee."
