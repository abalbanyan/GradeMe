# specify test command to run
exec python3 test.py
